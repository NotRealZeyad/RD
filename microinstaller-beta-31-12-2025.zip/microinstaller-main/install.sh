#!/bin/bash
if [ -z "$BASH" ]; then
    bash "$0" "$@"
    exit 0
fi
if [ "$(id -u)" != "0" ]; then
    sudo bash "$0" "$@"
    exit $?
fi
if [ "$(uname -m)" = "aarch64" ]; then
    echo "ARM is not supported yet."
    exit 1
fi

if [ -f /etc/os-release ]; then
    . /etc/os-release
    if [[ "$ID" != "debian" && "$ID" != "ubuntu" ]]; then
        echo "Only Debian and Ubuntu are supported."
        exit 1
    fi
else
    echo "Failed to detect the OS."
    exit 1
fi

clear
echo Checking if all packages are installed
apt install wget curl -y >/dev/null 2>&1
clear

echo Downloading MicroInstaller...
cp microinstaller-bios.sh /micro.sh
cp microinstaller-uefi.sh /micro2.sh
sleep 1
clear

echo Starting MicroInstaller...
echo MicroInstaller: v2025-6-21
echo Loading the menu...
sleep 2
clear
echo MicroInstaller: v2025-6-21
echo '**********************************************************'
echo Images:
#echo  [ 1 ]   Windows Server 2025
#echo  [ 2 ]   Windows Server 2022
#echo  [ 3 ]   Windows Server 2019
echo  [ 4 ]   Windows 11 LTSC UEFI
#echo  [ 5 ]   Windows Server 2012R2
echo  [ 6 ]   Windows 11 LTSC BIOS
#echo  [ 7 ]   Windows 10 LTSC
echo '**********************************************************'

echo -n "Select Image: "
read image

case $image in
    1) imagename="Windows Server 2025" ;;
    2) imagename="Windows Server 2022" ;;
    3) imagename="Windows Server 2019" ;;
    4) imagename="Windows 11 LTSC UEFI" ;;
    5) imagename="Windows Server 2012R2" ;;
    6) imagename="Windows 11 LTSC BIOS" ;;
    7) imagename="Windows 10 LTSC" ;;
    *) echo "Invalid image. Exiting."; exit 1 ;;
esac

sleep 1

clear

echo "MicroInstaller is gonna install $imagename to your machine's drive."
echo -n "Would you like to continue? (y/n): "
read confirm

if [[ "$confirm" == "y" || "$confirm" == "Y" ]]; then
    echo "Starting the installation..."
    /micro.sh -windows 11 >/dev/null 2>&1
else
    echo "Installation cancelled."
    exit 0
fi
