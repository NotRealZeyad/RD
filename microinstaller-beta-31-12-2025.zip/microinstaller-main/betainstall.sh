#!/bin/bash

if [ -z "$BASH" ]; then
    exec bash "$0" "$@"
fi

if [ "$(id -u)" != "0" ]; then
    exec sudo bash "$0" "$@"
fi

if [ "$(uname -m)" = "aarch64" ]; then
    echo "ARM is not supported yet."
    exit 1
fi

if [ -f /etc/os-release ]; then
    . /etc/os-release
    case "$ID" in
        debian|ubuntu) ;;
        *) echo "Only Debian and Ubuntu are supported."; exit 1 ;;
    esac
else
    echo "Failed to detect the OS."
    exit 1
fi

if [ -d /sys/firmware/efi ]; then
    FW_TYPE="UEFI"
    INSTALL_CMD="/micro.sh -windows 11" 
else
    FW_TYPE="BIOS"
    INSTALL_CMD="/micro.sh -windows 11"  
fi

clear
echo "Checking if all packages are installed…"
apt-get update -qq
apt-get install -y wget curl >/dev/null 2>&1
clear

cp microinstaller.sh  /micro.sh
chmod 777 /micro.sh
sleep 1
clear

echo "Starting MicroInstaller…"
echo "MicroInstaller: v2025‑12-30"
echo "Detected firmware: $FW_TYPE"
echo "Loading the menu…"
sleep 2
clear

echo "MicroInstaller: v2025‑12-30"
echo '**********************************************************'
echo "Images for $FW_TYPE systems:"
echo "  [ 1 ]   Windows 11 LTSC $FW_TYPE"
echo '**********************************************************'
read -rp "Select Image (default 1): " image
image=${image:-1}

if [ "$image" != "1" ]; then
    echo "Invalid selection. Exiting."
    exit 1
fi

imagename="Windows 11 LTSC $FW_TYPE"

clear
echo "MicroInstaller will install $imagename to your machine's drive."
read -rp "Would you like to continue? (y/n): " confirm

case "$confirm" in
    y|Y)
        echo "Starting the installation…"
        eval "$INSTALL_CMD" >/dev/null 2>&1
        echo "Type 'reboot' and press enter to reboot to the installer."
        ;;
    *)
        echo "Installation cancelled."
        exit 0
        ;;
esac
