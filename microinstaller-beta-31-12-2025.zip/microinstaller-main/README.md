# MicroInstaller
Microinstaller is a great way to reinstall your Linux VPS into a Windows VPS,

without the need to pay or modify stuff manually.



## Getting started
```bash
git clone https://github.com/rtedpro-cpu/microinstaller.git && cd microinstaller && bash betainstall.sh
```
